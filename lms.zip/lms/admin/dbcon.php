<?php
$conn = mysqli_connect('localhost','root','','capstone') or die(mysqli_error());
?>